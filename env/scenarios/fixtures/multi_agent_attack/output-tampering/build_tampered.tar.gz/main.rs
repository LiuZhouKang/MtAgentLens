fn main() { println!("ok"); }
